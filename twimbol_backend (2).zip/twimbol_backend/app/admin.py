from django.contrib import admin
from .models import *
from notifications.models import notifications, NotificationPrfeference
# Register your models here.
admin.site.register(Youtube_Video_Id_Title)
admin.site.register(Youtube_Video_Data)
admin.site.register(Post) 
admin.site.register(Youtube_Reels_Id)
admin.site.register(Youtube_Reels_Data)
admin.site.register(Post_Comment)
admin.site.register(Post_Stat_like)



admin.site.register(notifications)
